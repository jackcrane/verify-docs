// Import our dependencies
var request = require('request');
const express = require('express');
const bodyParser = require('body-parser');
const ejs = require('ejs');

// const JVERIFY_API_KEY = 'T3h5N3RyUPNT4NkQ73cuUtdh_cpNsXHG...' // Your JVerify API key. Get a key from jverify.us/dashboard
const JVERIFY_API_KEY = 'G_5NGIW7Es98iz5bt6VyTwrQ2G4vqZ8c1U2636rSQMh4NA13dRHu_G0lwSA2wl'

const port = 3000;

// Set up our Express engine and connect to EJS
const app = express();
app.set('view engine', 'ejs');

// Set up our first UI endpoint
app.get('/', (req, res) => {
  res.render('index.ejs', {})
})

// Create the API endpoint for our frontend to call to request the pin
app.post('/send-verification', bodyParser.json(), async (req, res) => {
  // Define request options
  var options = {
    'method': 'POST', // Needs to be a POST request
    'url': 'https://jverify.us/start',
    'headers': {
      'Content-Type': 'application/json' // We are sending JSON data. This is all that JVerify accepts right now.
    },
    body: JSON.stringify({ // Body of the request
      "key":JVERIFY_API_KEY,
      "name":"John Smith", // Name of the customer
      "vendor":"JVerify", // Name of your company
      "to":req.body.phone_num // Customer's phone number
    })
  };

  const JVerify_response = await request(options, (error, response) => {
    if (error) throw new Error(error); // Throw error if something went wrong
    const response_object = JSON.parse(response.body) // Decode response JSON string to JS Object
    if(response_object.success) { // Verify the message was sent successfully
      res.send(JSON.stringify({hash:response_object.hash})) // Send the hash to the client
    } else {
      // Handle if JVerify responded properly but something else went wrong
      throw new Error('Verification issue.');
    }
  });
})

// Create the API endpoint for our frontend to call to verify the pin
app.post('/check-verification', bodyParser.json(), async (req, res) => {
  var options = {
    'method': 'POST', // Needs to be a POST request
    'url': 'https://jverify.us/verify',
    'headers': {
      'Content-Type': 'application/json' // We are sending JSON data. This is all that JVerify accepts right now.
    },
    body: JSON.stringify({
      key:JVERIFY_API_KEY,
      hash:req.body.hash, // Hash returned from start API request. This can also be saved in session storage if you don't want to send to the client.
      pin:req.body.pin // Value from the pin input
    })
  };
  request(options, function (error, response) { // Send the request
    if (error) throw new Error(error); // Throw errors if something went wrong
    if(JSON.parse(response.body).correct) {
      // Backend logic if the pin was correct
      res.send(JSON.stringify({correct:true})) // Respond to the client
    } else {
      // Backend logic if the pin was incorrect
      res.send(JSON.stringify({correct:false})) // Respond to the client
    }
  });
})

// Start Express server
app.listen(port, () => {
  console.log(`Sample app listening at http://localhost:${port}`)
})
